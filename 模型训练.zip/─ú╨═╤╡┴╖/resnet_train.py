from torch.utils.data import DataLoader
from torchvision import transforms, datasets
from torch import optim
import torch
from torch import nn
from torchvision.models import resnet34
from tqdm import trange
from torch.utils.tensorboard import SummaryWriter

writer = SummaryWriter(log_dir='runs/loss')
writer1 = SummaryWriter(log_dir='runs/acc')

# 训练模型
def train():
    batch_size = 16

    model = resnet34()
    model.load_state_dict(torch.load("/data/wyx/resnet34-333f7ec4.pth"))

    fc_features = model.fc.in_features
    print(fc_features)

    model.fc = nn.Linear(fc_features, 13)

    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    model.to(device)

    loss_func = nn.CrossEntropyLoss()

    optimizer = optim.Adam(params=model.parameters(), lr=0.003)

    data_transform = {
        "train": transforms.Compose([transforms.RandomResizedCrop(256),
                                     transforms.CenterCrop(224),
                                     transforms.ToTensor(),
                                     transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])])}

    train_dataset = datasets.ImageFolder(root="/data/wangyx/MFCC-music/train",
                                         transform=data_transform["train"])
    train_loader = DataLoader(train_dataset, batch_size, shuffle=True, drop_last=True)

    for epoch in trange(100):
        model.train()
        loss_temp = 0
        correct = 0
        for j, (batch_data, batch_label) in enumerate(train_loader):

            batch_data, batch_label = batch_data.cuda(), batch_label.cuda()

            optimizer.zero_grad()

            prediction = model(batch_data)

            loss = loss_func(prediction, batch_label)
            loss_temp += loss.item()

            loss.backward()

            optimizer.step()

            #训练集准确率
            prediction = torch.max(prediction.data, 1)[1]
            correct += (prediction == batch_label).sum()
        print('[%d] loss: %.3f，acc：%.3f' % (epoch + 1, loss_temp / len(train_loader),correct/len(train_dataset)))

        test(model,epoch)
        writer.add_scalar(tag="loss/train", scalar_value=loss_temp / len(train_loader),
                          global_step=epoch + 1)
    # 保存模型
    torch.save(model, 'ResNet_model.pkl')

# 每轮测试
def test(model,epoch):
    model.eval()

    batch_size = 2

    correct = 0

    data_transform = {
        "test": transforms.Compose([transforms.RandomResizedCrop(256),
                                    transforms.CenterCrop(224),
                                    transforms.ToTensor(),
                                    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])])}

    test_dataset = datasets.ImageFolder(root="/data/wangyx/MFCC-music/test",
                                        transform=data_transform["test"])
    test_loader = DataLoader(test_dataset, batch_size, shuffle=True, drop_last=True)

    for batch_data, batch_label in test_loader:

        batch_data, batch_label = batch_data.cuda(), batch_label.cuda()

        prediction = model(batch_data)

        predicted = torch.max(prediction.data, 1)[1]
        # 获取准确个数
        correct += (predicted == batch_label).sum()
    print(correct / len(test_dataset))
    writer1.add_scalar(tag='acc', scalar_value=correct / len(test_dataset),global_step=epoch + 1)

if __name__ == '__main__':
    train()  # 训练
