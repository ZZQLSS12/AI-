# QQ音乐爬虫  

## 组成  

demo.js是QQ音乐js逆向有关的文件，其余四个PY文件是爬虫的主要代码.  

## 基本逻辑  

**总体来说，针对QQ音乐每个类别的热门歌手，爬取了TA的热门歌曲，并且进行类型转换、特征提取来构成数据集**  

1. musician.py中爬取了每个类别排行榜中的热门歌手  
2. music_id_list.py中根据热门歌手，获取了TA的热门歌曲的id序列  
3. translate_tool.py是将音乐进行格式转换和特征提取的文件，这一部分的编写得到了廖钰明的协助，我负责了改写和对接  
4. music_set.py是主要的爬虫实现，获取id后，根据id来进行歌曲爬取，得到二进制流数据后，再调用translate_tool.py文件来完成格式转换，构造了频谱图像或者各种特征表格类型的数据集  

## 参考资料  

js逆向工程部分的代码我参考了  
>【Python爬取QQ音乐歌曲数据（2023，9月23日公开课录播，讲师：巳月）】https://www.bilibili.com/video/BV1Nc41167rw?vd_source=3f26f0da20fb0a7fc09bb0537ea0f645  
