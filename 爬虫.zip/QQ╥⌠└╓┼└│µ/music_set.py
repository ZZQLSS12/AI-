import io
import time
from pydub import AudioSegment
import librosa
import requests
import execjs  # pip install pyexecjs
from tqdm import trange, tqdm
import music_id_list
import musician
import translate_tool
import pandas as pd
from multiprocessing.dummy import Pool

f = open('demo.js', mode='r', encoding='utf-8').read()
ctx = execjs.compile(f)
file_path = r"D:\桌面\music_top4.xlsx"# 改成自己的

headers = {
    'cookie':'RK=nbPVkksdVl; ptcz=95bd607a166220127becfa0ef0c3ccc6b7964cbe33cfe2c6811f2e8d79b3791f; logTrackKey=8293f58246e340cba793509142aa3421; pgv_pvid=2386901965; eas_sid=F1V69857S5G7X8F0G3l8h5G7z2; qq_domain_video_guid_verify=aa7debd5f3d2e8bd; _qimei_fingerprint=a2205b1acbeb721b1169f065ec2560b4; _qimei_q36=; _qimei_h38=58ca7d0a8b576c76d14babb602000006d17817; pac_uid=0_7df80415c16f4; iip=0; _qimei_uuid42=17b181338351007a283ce1640e7ae7bd36fa31dfc6; fqm_pvqid=0a296c78-d78f-4b1e-b402-b1bb8b6d6776; ts_uid=8010793662; tmeLoginType=2; music_ignore_pskey=202306271436Hn@vBj; _qpsvr_localtk=0.4619926021001348; fqm_sessionid=83aca923-e9c5-4dbe-b01a-146c99e1425e; pgv_info=ssid=s2880166160; ts_refer=www.baidu.com/link; login_type=1; psrf_qqopenid=875B7ABE38C1A99A7169ADE166EB7873; qm_keyst=Q_H_L_5U0SFZPJJOdvMSvIpUx6G55dZE9PSoto6w0pTgS4-qFRY11K0uH0MYw; euin=NeC5oKcF7KEs; wxopenid=; wxrefresh_token=; uin=861188596; qqmusic_key=Q_H_L_5U0SFZPJJOdvMSvIpUx6G55dZE9PSoto6w0pTgS4-qFRY11K0uH0MYw; psrf_qqunionid=202AE2D2DC414DDCC9F042959F1B4F6E; psrf_qqrefresh_token=F3A4AA95C64AF007094091C3FA1DD4E9; psrf_access_token_expiresAt=1710603997; psrf_musickey_createtime=1702827997; wxunionid=; psrf_qqaccess_token=C1C46A95A6DB2ED73F5EC275675AEF67; ts_last=y.qq.com/n/ryqq/singer_list',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36 Edg/119.0.0.0'
}

# 6 5 2
type_folder_list = [('7', 'pop'), ('3', 'hiphop'), ('19', 'chinoiserie'), ('4', 'rock'), ('2', 'elec'), ('8', 'folk'),
                    ('11', 'R&B'), ('37', 'national'), ('93', 'light'), ('14', 'jazz'), ('33', 'classic'),
                    ('13', 'country'), ('10', 'blues')]

count1 = 0
count2 = 0


def spider(ID):

    global count1

    for id_ in tqdm(ID):

        id_tuple = id_[0]

        count1 += 1
        guid_1 = ctx.call('getGuid')
        guid_2 = ctx.call('getGuid')
        songmid = id_tuple[0]
        songID = id_tuple[1]
        albumMid = id_tuple[2]

        data = '{"comm":{"cv":4747474,"ct":24,"format":"json","inCharset":"utf-8","outCharset":"utf-8","notice":0,"platform":"yqq.json","needNewCode":1,"uin":861188596,"g_tk_new_20200303":749194670,"g_tk":749194670},"req_1":{"module":"vkey.GetVkeyServer","method":"CgiGetVkey","param":{"guid":"' + guid_1 + '","songmid":["' + songmid + '"],"songtype":[0],"uin":"861188596","loginflag":1,"platform":"20"}},"req_2":{"module":"music.musicasset.SongFavRead","method":"IsSongFanByMid","param":{"v_songMid":["' + songmid + '"]}},"req_3":{"module":"music.musichallSong.PlayLyricInfo","method":"GetPlayLyricInfo","param":{"songMID":"' + songmid + '","songID":' + songID + '}},"req_4":{"method":"GetCommentCount","module":"music.globalComment.GlobalCommentRead","param":{"request_list":[{"biz_type":1,"biz_id":"' + songID + '","biz_sub_type":0}]}},"req_5":{"module":"music.musichallAlbum.AlbumInfoServer","method":"GetAlbumDetail","param":{"albumMid":"' + albumMid + '"}},"req_6":{"module":"vkey.GetVkeyServer","method":"CgiGetVkey","param":{"guid":"' + guid_2 + '","songmid":["' + songmid + '"],"songtype":[0],"uin":"861188596","loginflag":1,"platform":"20"}},"req_7":{"module":"music.trackInfo.UniformRuleCtrl","method":"CgiGetTrackInfo","param":{"ids":[' + songID + '],"types":[0]}}}'

        sign = ctx.call('sign', data)

        url = 'https://u.y.qq.com/cgi-bin/musics.fcg?sign=%s' % sign

        response = requests.post(url=url, headers=headers, data=data)
        purl = response.json()['req_1']['data']['midurlinfo'][0]['purl']

        if len(purl) == 0:
            print('successful')
            df = pd.DataFrame(
                columns=['title', 'Chroma Means', 'Chroma Vars', 'RMS Mean', 'RMS Variance', 'Spectral Centroid Mean',
                         'Spectral Centroid Variance', 'Spectral Bandwidth Mean', 'Spectral Bandwidth Variance',
                         'Roll-off Mean', 'Roll-off Variance', 'Zero Crossing Rate Mean', 'Zero Crossing Rate Variance',
                         'Harmony Mean', 'Harmony Variance', 'Tempo (BPM)', 'mel_specgram_mean', 'mel_specgram_var',
                         'mean_delta', 'var_delta', 'MFCC Means0', 'MFCC Vars0', 'MFCC Means1',
                         'MFCC Vars1', 'MFCC Means2', 'MFCC Vars2', 'MFCC Means3', 'MFCC Vars3', 'MFCC Means4',
                         'MFCC Vars4', 'MFCC Means5', 'MFCC Vars5', 'MFCC Means6', 'MFCC Vars6', 'MFCC Means7',
                         'MFCC Vars7', 'MFCC Means8', 'MFCC Vars8', 'MFCC Means9', 'MFCC Vars9',
                         'MFCC Means10', 'MFCC Vars10', 'MFCC Means11',
                         'MFCC Vars11', 'MFCC Means12', 'MFCC Vars12', 'MFCC Means13', 'MFCC Vars13', 'MFCC Means14',
                         'MFCC Vars14', 'MFCC Means15', 'MFCC Vars15', 'MFCC Means16', 'MFCC Vars16', 'MFCC Means17',
                         'MFCC Vars17', 'MFCC Means18', 'MFCC Vars18', 'MFCC Means19', 'MFCC Vars19',
                         'label'])

            temp = [df]
            return

        base_url = 'https://dl.stream.qqmusic.qq.com/'
        Url = base_url + purl
        music = requests.get(Url).content

        m4a_binary_data = music

        m4a_audio = AudioSegment.from_file(io.BytesIO(m4a_binary_data), format="m4a")
        wav_binary_data = m4a_audio.export(format="wav").read()

        title = response.json()['req_7']['data']['tracks'][0]['title']
        title = title.replace('(', '').replace(')', '')
        title = title.replace('<', '').replace('>', '')
        title = title.replace('-', '').replace('?', '')
        title = title.replace('"', '').replace('"', '')
        title = title.replace('/', '').replace('\\', '')
        title = title.replace('*', '').replace(':', '').replace('|', '')

        # 对应于main_spider()，以下两个函数分别对应调用

        # 1. 音乐数据转成图像
        # translate_tool.translate_pic(title, wav_binary_data, id_[1])

        # 2. 音乐数据转成表格数据
        return translate_tool.translate(title, wav_binary_data, id_[1])


count11 = 1


def main_spider():
    global count2, count11

    for i in trange(6,9, leave=False):
        start_row = 0
        musician_list = (musician.get_musician_list(
            'https://y.qq.com/n/ryqq/singer_list?index=-100&genre=' + type_folder_list[i][
                0] + '&sex=-100&area=-100'))
        for word_index in trange(len(musician_list)):
            word = musician_list[word_index]
            print(word_index)
            start_time = time.time()
            df = pd.DataFrame(
                columns=['title', 'Chroma Means', 'Chroma Vars', 'RMS Mean', 'RMS Variance', 'Spectral Centroid Mean',
                         'Spectral Centroid Variance', 'Spectral Bandwidth Mean', 'Spectral Bandwidth Variance',
                         'Roll-off Mean', 'Roll-off Variance', 'Zero Crossing Rate Mean', 'Zero Crossing Rate Variance',
                         'Harmony Mean', 'Harmony Variance', 'Tempo (BPM)', 'mel_specgram_mean', 'mel_specgram_var',
                         'mean_delta', 'var_delta', 'MFCC Means0', 'MFCC Vars0', 'MFCC Means1',
                         'MFCC Vars1', 'MFCC Means2', 'MFCC Vars2', 'MFCC Means3', 'MFCC Vars3', 'MFCC Means4',
                         'MFCC Vars4', 'MFCC Means5', 'MFCC Vars5', 'MFCC Means6', 'MFCC Vars6', 'MFCC Means7',
                         'MFCC Vars7', 'MFCC Means8', 'MFCC Vars8', 'MFCC Means9', 'MFCC Vars9',
                         'MFCC Means10', 'MFCC Vars10', 'MFCC Means11',
                         'MFCC Vars11', 'MFCC Means12', 'MFCC Vars12', 'MFCC Means13', 'MFCC Vars13', 'MFCC Means14',
                         'MFCC Vars14', 'MFCC Means15', 'MFCC Vars15', 'MFCC Means16', 'MFCC Vars16', 'MFCC Means17',
                         'MFCC Vars17', 'MFCC Means18', 'MFCC Vars18', 'MFCC Means19', 'MFCC Vars19',
                         'label'])
            datalist = []

            ID_list = music_id_list.get_ID_list(word)
            existing_data = pd.read_excel(file_path)
            label_list = []
            for j in range(10):
                label_list.append(type_folder_list[i][1])
            ID_label_list = list(zip(ID_list, label_list))

            # 以下两个功能分开使用
            # 1. 爬取音乐转成图像
            # spider(ID_label_list)

            # 2. 爬取音乐生成表格类型数据
            # 多线程爬取，考虑到电脑性能，只开了5个线程
            pool = Pool(5)

            results = pool.map(spider, ID_label_list[0:5])
            for result in results:
                for item in result:
                    existing_data = pd.concat([existing_data, item], ignore_index=True)

            results = pool.map(spider, ID_label_list[5:10])
            for result in results:
                for item in result:
                    existing_data = pd.concat([existing_data, item], ignore_index=True)

            df = pd.concat([df, existing_data], ignore_index=True)
            print(existing_data)
            df.to_excel(file_path, index=False, sheet_name=type_folder_list[i][1])
            start_row += len(datalist)
            end_time = time.time()
            print('over:' + str(end_time - start_time))


main_spider()
