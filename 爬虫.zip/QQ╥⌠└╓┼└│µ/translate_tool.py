import numpy as np
from tqdm import tqdm
import pandas as pd
import librosa
import io
import os
from tqdm import trange
import matplotlib.pyplot as plt


def translate_pic(title, content,label):

    savepath = r"D:\桌面\新建文件夹 (2)"
    y, sr = librosa.load(io.BytesIO(content), sr=None)
    segment_length = 10 * sr
    base_length = 20 * sr
    y = y[int(base_length):int(segment_length + base_length)]

    mfcc = librosa.feature.mfcc(y=y, sr=sr)
    plt.figure(figsize=(10, 4))
    librosa.display.specshow(mfcc)
    plt.axis("off")  # 关闭横轴和纵轴标注
    plt.savefig(savepath+'\\'+label+'\\'+title+'fig.jpg')  # 可以根据需要修改文件路径和格式
    plt.close()



def translate(title, content,label):
    datalist=[]
    segment = []
    y_, sr = librosa.load(io.BytesIO(content), sr=None)
    audio_length = len(y_)/sr
    segment_length_s = 10
    base_length_s = 20
    segment_length = 10*sr
    base_length = 20*sr
    if audio_length > segment_length_s + base_length_s:
        segment.append(y_[int(base_length):int(segment_length + base_length)])
    if audio_length > 2 * segment_length_s + base_length_s:
        segment.append(y_[int(segment_length + base_length):int(2 * segment_length + base_length)])
    if audio_length > 3 * segment_length_s + base_length_s:
        segment.append(y_[int(2 * segment_length + base_length):int(3 * segment_length + base_length)])
    for i in trange(len(segment)):

        # 提取chroma_stft特征
        y = segment[i]
        # translatepic(y,sr,label,title+str(i),savepath=r"D:\桌面\music_top_fig",)

        chroma = librosa.feature.chroma_stft(y=y, sr=sr)
        chroma_means = np.mean(chroma)
        chroma_vars = np.var(chroma)

        # 计算RMS
        rms = librosa.feature.rms(y=y)
        rms_mean = rms.mean()
        rms_var = rms.var()

        # 计算频谱中心
        spectral_centroids = librosa.feature.spectral_centroid(y=y, sr=sr)
        spectral_centroids_mean = spectral_centroids.mean()
        spectral_centroids_var = spectral_centroids.var()

        # 计算ji
        spectral_bandwidths = librosa.feature.spectral_bandwidth(y=y, sr=sr)
        spectral_bandwidths_mean = spectral_bandwidths.mean()
        spectral_bandwidths_var = spectral_bandwidths.var()

        # 计算rolloff
        rolloffs = librosa.feature.spectral_rolloff(y=y, sr=sr)
        rolloffs_mean = rolloffs.mean()
        rolloffs_var = rolloffs.var()

        # 计算过零率
        zero_crossing_rates = librosa.feature.zero_crossing_rate(y)
        zero_crossing_rates_mean = zero_crossing_rates.mean()
        zero_crossing_rates_var = zero_crossing_rates.var()

        # 计算谐振
        harmonics = librosa.effects.harmonic(y)
        harmonics_mean = harmonics.mean()
        harmonics_var = harmonics.var()

        # 计算节奏（BPM）
        tempo = librosa.feature.tempo(y=y, sr=sr)

        # # 计算梅尔频谱图的均值
        mel_specgram = librosa.feature.melspectrogram(y=y, sr=sr)
        mel_specgram_mean = np.mean(mel_specgram)
        mel_specgram_var = np.var(mel_specgram)
        #
        # 计算反演的STFT的均值和方差
        # stft_specgram = librosa.feature.inverse.mel_to_stft(mel_specgram)
        # mean_stft = np.mean(stft_specgram)
        # var_stft = np.var(stft_specgram)
        #
        # # 计算 delta 特征
        delta_mel = librosa.feature.delta(mel_specgram)
        mean_delta = np.mean(delta_mel)
        var_delta = np.var(delta_mel)

        # # 提取MFCC特征
        mfcc = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=20)###############################
        mfcc_means = np.mean(mfcc, axis=1)
        mfcc_vars = np.var(mfcc, axis=1)

        # 创建一个字典，存储特征数据
        features = {
            'title': title + '-' + str(i),
            'Chroma Means': chroma_means,
            'Chroma Vars': chroma_vars,
            'RMS Mean': [rms_mean],
            'RMS Variance': [rms_var],
            'Spectral Centroid Mean': [spectral_centroids_mean],
            'Spectral Centroid Variance': [spectral_centroids_var],
            'Spectral dth Mean': [spectral_bandwidths_mean],
            'Spectral Bandwidth Variance': [spectral_bandwidths_var],
            'Roll-off Mean': [rolloffs_mean],
            'Roll-off Variance': [rolloffs_var],
            'Zero Crossing Rate Mean': [zero_crossing_rates_mean],
            'Zero Crossing Rate Variance': [zero_crossing_rates_var],
            'Harmony Mean': [harmonics_mean],
            'Harmony Variance': [harmonics_var],
            'Tempo (BPM)': tempo,
            'mel_specgram_mean':mel_specgram_mean,
            'mel_specgram_var':mel_specgram_var,
            'mean_delta':mean_delta,
            'var_delta':var_delta,
            'MFCC Means0': mfcc_means[0],
            'MFCC Vars0': mfcc_vars[0],
            'MFCC Means1': mfcc_means[1],
            'MFCC Vars1': mfcc_vars[1],
            'MFCC Means2': mfcc_means[2],
            'MFCC Vars2': mfcc_vars[2],
            'MFCC Means3': mfcc_means[3],
            'MFCC Vars3': mfcc_vars[3],
            'MFCC Means4': mfcc_means[4],
            'MFCC Vars4': mfcc_vars[4],
            'MFCC Means5': mfcc_means[5],
            'MFCC Vars5': mfcc_vars[5],
            'MFCC Means6': mfcc_means[6],
            'MFCC Vars6': mfcc_vars[6],
            'MFCC Means7': mfcc_means[7],
            'MFCC Vars7': mfcc_vars[7],
            'MFCC Means8': mfcc_means[8],
            'MFCC Vars8': mfcc_vars[8],
            'MFCC Means9': mfcc_means[9],
            'MFCC Vars9': mfcc_vars[9],
            'MFCC Means10': mfcc_means[10],
            'MFCC Vars10': mfcc_vars[10],
            'MFCC Means11': mfcc_means[11],
            'MFCC Vars11': mfcc_vars[11],
            'MFCC Means12': mfcc_means[12],
            'MFCC Vars12': mfcc_vars[12],
            'MFCC Means13': mfcc_means[13],
            'MFCC Vars13': mfcc_vars[13],
            'MFCC Means14': mfcc_means[14],
            'MFCC Vars14': mfcc_vars[14],
            'MFCC Means15': mfcc_means[15],
            'MFCC Vars15': mfcc_vars[15],
            'MFCC Means16': mfcc_means[16],
            'MFCC Vars16': mfcc_vars[16],
            'MFCC Means17': mfcc_means[17],
            'MFCC Vars17': mfcc_vars[17],
            'MFCC Means18': mfcc_means[18],
            'MFCC Vars18': mfcc_vars[18],
            'MFCC Means19': mfcc_means[19],
            'MFCC Vars19': mfcc_vars[19],
            'label':label

        }
        df = pd.DataFrame(features)
        datalist.append(df)

    return datalist
