import requests
import execjs


def get_ID_list(query):
    f = open('demo.js', mode='r', encoding='utf-8').read()
    ctx = execjs.compile(f)

    headers = {
        'cookie': 'RK=nbPVkksdVl; ptcz=95bd607a166220127becfa0ef0c3ccc6b7964cbe33cfe2c6811f2e8d79b3791f; logTrackKey=8293f58246e340cba793509142aa3421; pgv_pvid=2386901965; eas_sid=F1V69857S5G7X8F0G3l8h5G7z2; qq_domain_video_guid_verify=aa7debd5f3d2e8bd; _qimei_fingerprint=a2205b1acbeb721b1169f065ec2560b4; _qimei_q36=; _qimei_h38=58ca7d0a8b576c76d14babb602000006d17817; pac_uid=0_7df80415c16f4; iip=0; _qimei_uuid42=17b181338351007a283ce1640e7ae7bd36fa31dfc6; fqm_pvqid=0a296c78-d78f-4b1e-b402-b1bb8b6d6776; ts_uid=8010793662; tmeLoginType=2; music_ignore_pskey=202306271436Hn@vBj; _qpsvr_localtk=0.4619926021001348; fqm_sessionid=83aca923-e9c5-4dbe-b01a-146c99e1425e; pgv_info=ssid=s2880166160; ts_refer=www.baidu.com/link; login_type=1; psrf_qqopenid=875B7ABE38C1A99A7169ADE166EB7873; qm_keyst=Q_H_L_5U0SFZPJJOdvMSvIpUx6G55dZE9PSoto6w0pTgS4-qFRY11K0uH0MYw; euin=NeC5oKcF7KEs; wxopenid=; wxrefresh_token=; uin=861188596; qqmusic_key=Q_H_L_5U0SFZPJJOdvMSvIpUx6G55dZE9PSoto6w0pTgS4-qFRY11K0uH0MYw; psrf_qqunionid=202AE2D2DC414DDCC9F042959F1B4F6E; psrf_qqrefresh_token=F3A4AA95C64AF007094091C3FA1DD4E9; psrf_access_token_expiresAt=1710603997; psrf_musickey_createtime=1702827997; wxunionid=; psrf_qqaccess_token=C1C46A95A6DB2ED73F5EC275675AEF67; ts_last=y.qq.com/n/ryqq/singer_list',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36 Edg/119.0.0.0'
    }

    searchId = ctx.call('searchId')
    search_data = '{"comm":{"cv":4747474,"ct":24,"format":"json","inCharset":"utf-8","outCharset":"utf-8","notice":0,"platform":"yqq.json","needNewCode":1,"uin":861188596,"g_tk_new_20200303":749194670,"g_tk":749194670},"req_1":{"method":"DoSearchForQQMusicDesktop","module":"music.search.SearchCgiService","param":{"remoteplace":"txt.yqq.top","searchid":"%s","search_type":0,"query":"%s","page_num":1,"num_per_page":10}}}' % (
        searchId, query)
    search_sign = ctx.call('sign', search_data)
    search_url = 'https://u.y.qq.com/cgi-bin/musics.fcg?sign=%s' % search_sign
    search_data = search_data.encode('utf-8')
    search_response = requests.post(url=search_url, data=search_data, headers=headers)

    content = search_response.json()

    # songmid = '00128N3r2SYKMF'
    # songID = '449201'
    # albumMid = '002Neh8l0uciQZ'
    songmid_list=[]
    songID_list=[]
    albumMid_list=[]
    for i in range(10):
        temp = content['req_1']['data']['body']['song']['list'][i]
        songmid_list.append(temp['mid'])
        songID_list.append(str(temp['id']))
        albumMid_list.append(str(temp['album']['id']))

    ID_list=list(zip(songmid_list,songID_list,albumMid_list))

    return ID_list




