import requests
from lxml import etree
import urllib

def get_musician_list(url):

    headers = {
        'cookie': 'RK=nbPVkksdVl; ptcz=95bd607a166220127becfa0ef0c3ccc6b7964cbe33cfe2c6811f2e8d79b3791f; logTrackKey=8293f58246e340cba793509142aa3421; pgv_pvid=2386901965; eas_sid=F1V69857S5G7X8F0G3l8h5G7z2; qq_domain_video_guid_verify=aa7debd5f3d2e8bd; _qimei_fingerprint=a2205b1acbeb721b1169f065ec2560b4; _qimei_q36=; _qimei_h38=58ca7d0a8b576c76d14babb602000006d17817; pac_uid=0_7df80415c16f4; iip=0; _qimei_uuid42=17b181338351007a283ce1640e7ae7bd36fa31dfc6; fqm_pvqid=0a296c78-d78f-4b1e-b402-b1bb8b6d6776; ts_uid=8010793662; tmeLoginType=2; music_ignore_pskey=202306271436Hn@vBj; _qpsvr_localtk=0.4619926021001348; fqm_sessionid=83aca923-e9c5-4dbe-b01a-146c99e1425e; pgv_info=ssid=s2880166160; ts_refer=www.baidu.com/link; login_type=1; psrf_qqopenid=875B7ABE38C1A99A7169ADE166EB7873; qm_keyst=Q_H_L_5U0SFZPJJOdvMSvIpUx6G55dZE9PSoto6w0pTgS4-qFRY11K0uH0MYw; euin=NeC5oKcF7KEs; wxopenid=; wxrefresh_token=; uin=861188596; qqmusic_key=Q_H_L_5U0SFZPJJOdvMSvIpUx6G55dZE9PSoto6w0pTgS4-qFRY11K0uH0MYw; psrf_qqunionid=202AE2D2DC414DDCC9F042959F1B4F6E; psrf_qqrefresh_token=F3A4AA95C64AF007094091C3FA1DD4E9; psrf_access_token_expiresAt=1710603997; psrf_musickey_createtime=1702827997; wxunionid=; psrf_qqaccess_token=C1C46A95A6DB2ED73F5EC275675AEF67; ts_last=y.qq.com/n/ryqq/singer_list',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36 Edg/119.0.0.0'
    }

    # url = 'https://y.qq.com/n/ryqq/singer_list?index=-100&genre=3&sex=-100&area=-100'

    request = urllib.request.Request(url=url,headers=headers)

    response = urllib.request.urlopen(request)

    content = response.read().decode('utf-8')

    tree = etree.HTML(content)

    result_top10 = tree.xpath('//h3[@class="singer_list__title"]/a/text()')

    print(result_top10)
    print(f'共有{len(result_top10)}名')
    return result_top10

    # return result_top10[5:10]
    # result_others= tree.xpath('//a[@class="singer_list_txt__link js_singer"]/text()')
    # return result_others[5:10]
    #
    # print(result_others)
    # print(f'共有{len(result_others)}名')


# get_musician_list('https://y.qq.com/n/ryqq/singer_list?index=-100&genre=3&sex=-100&area=-100')

